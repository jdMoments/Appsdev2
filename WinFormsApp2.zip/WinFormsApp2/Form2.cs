﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form2 : Form
    {
        double result = 0;
        public Form2()
        {
            InitializeComponent();
        }
        public void scanData(char operation, double operand)
        {
            doNextOperation(operation, operand);
        }
        public void doNextOperation(char operation, double operand)
        {
            switch(operation)
            {
                case '+':
                    result += operand;
                    listBox1.Items.Add(operation + " " + operand);
                    listBox1.Items.Add("the result so far is " + result);
                    break;
                case '-':
                    result -= operand;
                    listBox1.Items.Add(operation + " " + operand);
                    listBox1.Items.Add("the result so far is " + result);
                    break;
                case '*':
                    result *= operand;
                    listBox1.Items.Add(operation + " " + operand);
                    listBox1.Items.Add("the result so far is " + result);
                    break;
                case '/':
                    result /= operand;
                    listBox1.Items.Add(operation + " " + operand);
                    listBox1.Items.Add("the result so far is " + result);
                    break;
                case '^':
                    result = Math.Pow(result, operand);
                    listBox1.Items.Add(operation + " " + operand);
                    listBox1.Items.Add("the result so far is " + result);
                    break;
                case 'q':
                    Close();
                    break;
            }
        }
    }
}
