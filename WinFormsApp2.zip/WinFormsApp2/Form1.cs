namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        Form2 form2 = new Form2();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char operation = Convert.ToChar(textBox1.Text);
            double num = Convert.ToDouble(textBox2.Text);
            form2.scanData(operation, num);
            form2.Show();
            textBox1.Clear();
            textBox2.Clear();
        }
        private void keyPressedEnter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                char operation = Convert.ToChar(textBox1.Text);
                double num = Convert.ToDouble(textBox2.Text);
                form2.scanData(operation, num);
                form2.Show();
                textBox1.Clear();
                textBox2.Clear();
            }
        }
    }
}
